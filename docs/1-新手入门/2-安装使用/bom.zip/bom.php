<?php

/**
 * 文件异常排查
 */

header('Content-Type: text/html; charset=utf-8');

$auto = 1;

define('ROOTPATH', dirname(__FILE__));

echo '检查开始<hr>';
checkdir(ROOTPATH);
echo '<hr>检查完毕';

function checkdir($basedir){
    if ($dh = opendir($basedir)) {
        while (($file = readdir($dh)) !== false) {
            if ($file != '.' && $file != '..'){
                if (!is_dir($basedir."/".$file)) {
					if (trim(strtolower(strrchr($file, '.')), '.') == 'php') {
						$rt = checkBOM("$basedir/$file");
						if ($rt) {
							echo "文件：$basedir/$file ".$rt." <br>";
						}
					}
                }else{
                    $dirname = $basedir."/".$file;
                    checkdir($dirname);
                }
            }
        }
        closedir($dh);
    }
}

function checkBOM ($filename) {
    global $auto;
    $contents = file_get_contents($filename);
    $charset[1] = substr($contents, 0, 1);
    $charset[2] = substr($contents, 1, 1);
    $charset[3] = substr($contents, 2, 1);
    if (ord($charset[1]) == 239 && ord($charset[2]) == 187 && ord($charset[3]) == 191) {
        return ("<font color=red>存在问题</font>");
    } else {
		return '';
	};
}

